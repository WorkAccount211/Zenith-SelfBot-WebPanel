import asyncio
import datetime
from discord.ext import commands
import discord

def register_moderation_commands(bot):
    """Регистрация 20+ команд модерации и продвинутой системы предупреждений (warn/mute/kick/ban)."""

    # 1-10: Предупреждения и Модерация участников
    @bot.command(name="warn", aliases=["варн", "предупредить"])
    async def warn_cmd(ctx, target: discord.User, *, reason: str = "Нарушение правил"):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Команда доступна только на сервере.")
            return

        guild_id = str(ctx.guild.id)
        user_id = str(target.id)
        mod_id = str(ctx.author.id)

        warn_id, warn_count, auto_muted = await bot.db.add_warning(
            guild_id=guild_id,
            user_id=user_id,
            moderator_id=mod_id,
            reason=reason,
            user_name=target.name,
            moderator_name=ctx.author.name
        )

        msg = (
            f"⚠️ **Предупреждение выдано:** {target.mention}\n"
            f"> 🆔 ID варна: `#{warn_id}`\n"
            f"> 📌 Причина: *{reason}*\n"
            f"> 📊 Текущие варны: `{warn_count}/4`"
        )

        if auto_muted or warn_count >= 4:
            msg += "\n\n🚨 **ДОСТИГНУТ ЛИМИТ 4/4 ПРЕДУПРЕЖДЕНИЙ!**"
            member = ctx.guild.get_member(target.id)
            if member:
                try:
                    mute_duration = datetime.timedelta(hours=1)
                    await member.timeout(mute_duration, reason="Превышение 4 предупреждений (Авто-мут на 1 час)")
                    msg += "\n🔇 Пользователю выдан **Тайм-аут (Мут) на 1 час** в Discord!"
                except Exception as ex:
                    msg += f"\n*(Мут активирован в базе данных; ошибка Discord timeout: {ex})*"
            else:
                msg += "\n🔇 Авто-мут на 1 час зафиксирован в базе данных."

        await bot.send_routed(ctx, msg, route_type="moderation")

    @bot.command(name="warns", aliases=["варны", "список_варнов"])
    async def warns_cmd(ctx, target: discord.User = None):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Команда доступна только на сервере.")
            return

        u = target or ctx.author
        warns = await bot.db.get_warnings(str(ctx.guild.id), str(u.id))
        is_muted, mute_reason, mute_until = await bot.db.is_user_muted(str(ctx.guild.id), str(u.id))

        if not warns:
            mute_status = f"\n🔇 **Статус:** В муте до `{mute_until}` (*{mute_reason}*)" if is_muted else ""
            await ctx.send(f"🛡️ У пользователя {u.name} нет активных предупреждений (0/4).{mute_status}")
            return

        lines = [f"📋 **Предупреждения {u.name} (`{len(warns)}/4`):**\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"]
        for w in warns:
            lines.append(f"• ID `#{w['id']}` [{w['created_at'][:16]}]: *{w['reason']}* (Модератор: <@{w['moderator_id']}>)")

        if is_muted:
            lines.append(f"\n🔇 **Активный мут:** до `{mute_until}` | Причина: *{mute_reason}*")

        await bot.send_routed(ctx, "\n".join(lines), route_type="moderation")

    @bot.command(name="clearwarns", aliases=["очистить_варны", "снять_все_варны"])
    async def clearwarns_cmd(ctx, target: discord.User):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        count = await bot.db.clear_warnings(str(ctx.guild.id), str(target.id))
        await bot.db.unmute_user(str(ctx.guild.id), str(target.id))
        await bot.send_routed(ctx, f"✅ С пользователя {target.mention} сняты все предупреждения (`{count}` шт.) и аннулирован статус мута.", route_type="moderation")

    @bot.command(name="delwarn", aliases=["удалить_варн", "снять_варн"])
    async def delwarn_cmd(ctx, warn_id: int):
        await bot.handle_slowmode(ctx.channel)
        ok = await bot.db.delete_warning_by_id(warn_id)
        if ok:
            await ctx.send(f"✅ Предупреждение `#{warn_id}` успешно аннулировано.")
        else:
            await ctx.send(f"❌ Варн `#{warn_id}` не найден.")

    @bot.command(name="kick", aliases=["кик", "выгнать"])
    async def kick_cmd(ctx, member: discord.Member, *, reason: str = "Исключен модератором"):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if not ctx.author.guild_permissions.kick_members and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на исключение участников (Kick Members).")
            return
        try:
            await member.kick(reason=reason)
            await bot.db.log_event("WARN", f"Пользователь {member.name} ({member.id}) исключен. Причина: {reason}", "moderation")
            await bot.send_routed(ctx, f"👢 **Участник {member.name} исключен с сервера!**\n> Причина: *{reason}*", route_type="moderation")
        except discord.Forbidden:
            await ctx.send("❌ Ошибка 403: недостаточно прав для исключения (проверьте права бота).")
        except Exception as e:
            await ctx.send(f"❌ Ошибка исключения участника: {e}")

    @bot.command(name="ban", aliases=["бан", "забанить"])
    async def ban_cmd(ctx, user: discord.User, *, reason: str = "Заблокирован модератором"):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if not ctx.author.guild_permissions.ban_members and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на блокировку участников (Ban Members).")
            return
        try:
            await ctx.guild.ban(user, reason=reason)
            await bot.db.log_event("WARN", f"Пользователь {user.name} ({user.id}) забанен. Причина: {reason}", "moderation")
            await bot.send_routed(ctx, f"🔨 **Пользователь {user.name} успешно заблокирован!**\n> Причина: *{reason}*", route_type="moderation")
        except discord.Forbidden:
            await ctx.send("❌ Ошибка 403: недостаточно прав для блокировки (проверьте права бота).")
        except Exception as e:
            await ctx.send(f"❌ Ошибка блокировки: {e}")

    @bot.command(name="unban", aliases=["унбан", "разбанить"])
    async def unban_cmd(ctx, user_id: int):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if not ctx.author.guild_permissions.ban_members and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на разблокировку (Ban Members).")
            return
        try:
            user = await bot.fetch_user(user_id)
            await ctx.guild.unban(user)
            await bot.db.log_event("INFO", f"Пользователь {user.name} ({user_id}) разбанен", "moderation")
            await bot.send_routed(ctx, f"🕊️ **Пользователь {user.name} (`{user_id}`) успешно разблокирован!**", route_type="moderation")
        except discord.NotFound:
            await ctx.send("❌ Пользователь с таким ID не найден в бан-листе.")
        except discord.Forbidden:
            await ctx.send("❌ Ошибка 403: недостаточно прав для разблокировки (проверьте права бота).")
        except Exception as e:
            await ctx.send(f"❌ Ошибка разблокировки: {e}")

    # --- Исправленная команда mute (с поддержкой бесконечного мута) ---
    @bot.command(name="mute", aliases=["мут", "таймаут", "timeout"])
    async def mute_cmd(ctx, member: discord.Member, minutes: int = 60, *, reason: str = "Нарушение порядка"):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if not ctx.author.guild_permissions.kick_members and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на выдачу мута (требуется Kick Members).")
            return

        # Если minutes == 0 – бесконечный мут (используем роль Muted)
        if minutes == 0:
            muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
            if muted_role is None:
                if not ctx.guild.me.guild_permissions.manage_roles:
                    await ctx.send("❌ У бота нет прав на создание роли Muted.")
                    return
                muted_role = await ctx.guild.create_role(
                    name="Muted",
                    permissions=discord.Permissions.none(),
                    reason="Роль для бесконечного мута"
                )
                # Запрещаем отправку сообщений, добавление реакций, подключение к голосовым для роли
                for channel in ctx.guild.channels:
                    try:
                        await channel.set_permissions(muted_role, send_messages=False, add_reactions=False, speak=False, connect=False)
                    except:
                        pass
            try:
                await member.add_roles(muted_role, reason=reason)
                await bot.db.mute_user(str(ctx.guild.id), str(member.id), 0, reason)  # 0 = бесконечный в БД
                await bot.db.log_event("WARN", f"Пользователь {member.name} получил бесконечный мут (роль Muted). Причина: {reason}", "moderation")
                await bot.send_routed(ctx, f"🔇 **{member.name} отправлен в бесконечный мут (роль Muted).**\n> Причина: *{reason}*", route_type="moderation")
            except discord.Forbidden:
                await ctx.send("❌ Ошибка 403: недостаточно прав для выдачи роли Muted.")
            except Exception as e:
                await ctx.send(f"❌ Ошибка выдачи бесконечного мута: {e}")
            return

        # Обычный тайм-аут
        try:
            # Ограничение Discord: максимум 28 дней (40320 минут)
            max_minutes = 28 * 24 * 60
            if minutes > max_minutes:
                minutes = max_minutes
                await ctx.send(f"⚠️ Максимальный срок мута – 28 дней. Установлено {max_minutes} мин.")
            dur = datetime.timedelta(minutes=minutes)
            await member.timeout(dur, reason=reason)
            await bot.db.mute_user(str(ctx.guild.id), str(member.id), minutes * 60, reason)
            await bot.db.log_event("WARN", f"Пользователь {member.name} отправлен в мут на {minutes}м. Причина: {reason}", "moderation")
            await bot.send_routed(ctx, f"🔇 **{member.name} отправлен в мут на {minutes} мин.**\n> Причина: *{reason}*", route_type="moderation")
        except discord.Forbidden:
            await ctx.send("❌ Ошибка 403: недостаточно прав для выдачи мута (проверьте права бота на управление участниками).")
        except discord.HTTPException as e:
            await ctx.send(f"❌ Ошибка HTTP: {e} (возможно, неверный формат времени).")
        except Exception as e:
            await ctx.send(f"❌ Ошибка установки мута: {e}")

    @bot.command(name="unmute", aliases=["размут", "снять_таймаут"])
    async def unmute_cmd(ctx, member: discord.Member):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if not ctx.author.guild_permissions.kick_members and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на снятие мута (требуется Kick Members).")
            return
        try:
            # Снимаем тайм-аут
            await member.timeout(None)
            # Убираем роль Muted (если есть)
            muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
            if muted_role and muted_role in member.roles:
                await member.remove_roles(muted_role, reason="Снятие мута")
            await bot.db.unmute_user(str(ctx.guild.id), str(member.id))
            await bot.db.log_event("INFO", f"С пользователя {member.name} снят мут", "moderation")
            await bot.send_routed(ctx, f"🔊 **Тайм-аут с {member.name} успешно снят!**", route_type="moderation")
        except discord.Forbidden:
            await ctx.send("❌ Ошибка 403: недостаточно прав для снятия мута.")
        except Exception as e:
            await ctx.send(f"❌ Ошибка снятия мута: {e}")

    @bot.command(name="purge", aliases=["очистить", "клир", "clear"])
    async def purge_cmd(ctx, limit: int = 10):
        try:
            await ctx.message.delete()
        except Exception:
            pass
        deleted = 0
        async for m in ctx.channel.history(limit=limit):
            if m.author.id == bot.user.id:
                try:
                    await m.delete()
                    deleted += 1
                    await asyncio.sleep(0.3)
                except Exception:
                    pass
        res = await ctx.send(f"🧹 Очищено `{deleted}` собственных сообщений.")
        await asyncio.sleep(2)
        try:
            await res.delete()
        except Exception:
            pass

    # --- Исправленные команды slowmode, lock, unlock, clearslowmode ---
    @bot.command(name="slowmode", aliases=["слоумод", "медленный_режим"])
    async def slowmode_cmd(ctx, seconds: int):
        await bot.handle_slowmode(ctx.channel)
        if seconds < 0 or seconds > 21600:
            await ctx.send("❌ Значение должно быть от 0 до 21600 секунд.")
            return
        try:
            await ctx.channel.edit(slowmode_delay=seconds)
            await ctx.send(f"⏳ Медленный режим канала установлен на **`{seconds}` сек.**")
        except discord.Forbidden:
            await ctx.send("❌ У бота нет прав на изменение настроек канала.")
        except Exception as e:
            await ctx.send(f"❌ Ошибка: {e}")

    @bot.command(name="clearslowmode", aliases=["снять_слоумод", "отключить_слоумод"])
    async def clearslowmode_cmd(ctx):
        await bot.handle_slowmode(ctx.channel)
        try:
            await ctx.channel.edit(slowmode_delay=0)
            await ctx.send("⏳ Медленный режим отключён.")
        except discord.Forbidden:
            await ctx.send("❌ У бота нет прав на изменение настроек канала.")
        except Exception as e:
            await ctx.send(f"❌ Ошибка: {e}")

    @bot.command(name="lock", aliases=["заблокировать_чат"])
    async def lock_cmd(ctx):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if not ctx.author.guild_permissions.manage_channels and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на управление каналами.")
            return
        try:
            channel = ctx.channel
            # Сохраняем текущий overwrite для @everyone (если есть)
            current_overwrite = channel.overwrites_for(ctx.guild.default_role)
            # Сохраняем в атрибуте бота
            if not hasattr(bot, 'locked_overwrites'):
                bot.locked_overwrites = {}
            bot.locked_overwrites[channel.id] = current_overwrite
            # Устанавливаем запрет на отправку
            await channel.set_permissions(ctx.guild.default_role, send_messages=False)
            await ctx.send("🔒 **Канал заблокирован для отправки сообщений.**")
        except discord.Forbidden:
            await ctx.send("❌ У бота нет прав на изменение разрешений канала.")
        except Exception as e:
            await ctx.send(f"❌ Ошибка: {e}")

    @bot.command(name="unlock", aliases=["разблокировать_чат"])
    async def unlock_cmd(ctx):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if not ctx.author.guild_permissions.manage_channels and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на управление каналами.")
            return
        try:
            channel = ctx.channel
            # Проверяем, сохранён ли старый overwrite
            if not hasattr(bot, 'locked_overwrites'):
                bot.locked_overwrites = {}
            old = bot.locked_overwrites.pop(channel.id, None)
            if old is not None:
                # Восстанавливаем старые права
                await channel.set_permissions(ctx.guild.default_role, overwrite=old)
            else:
                # Если не сохранён, просто убираем запрет (удаляем переопределение)
                await channel.set_permissions(ctx.guild.default_role, overwrite=None)
            await ctx.send("🔓 **Канал разблокирован.**")
        except discord.Forbidden:
            await ctx.send("❌ У бота нет прав на изменение разрешений канала.")
        except Exception as e:
            await ctx.send(f"❌ Ошибка: {e}")

    # --- Команды для работы с ролями ---
    @bot.command(name="addrole", aliases=["выдать_роль"])
    async def addrole_cmd(ctx, member: discord.Member, role: discord.Role):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.author.guild_permissions.manage_roles and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на управление ролями.")
            return
        try:
            await member.add_roles(role)
            await ctx.send(f"✅ Роль **{role.name}** выдана пользователю {member.mention}.")
        except discord.Forbidden:
            await ctx.send("❌ У бота нет прав на выдачу этой роли.")
        except Exception as e:
            await ctx.send(f"❌ Ошибка выдачи роли: {e}")

    @bot.command(name="removerole", aliases=["снять_роль"])
    async def removerole_cmd(ctx, member: discord.Member, role: discord.Role):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.author.guild_permissions.manage_roles and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на управление ролями.")
            return
        try:
            await member.remove_roles(role)
            await ctx.send(f"✅ Роль **{role.name}** снята с пользователя {member.mention}.")
        except discord.Forbidden:
            await ctx.send("❌ У бота нет прав на снятие этой роли.")
        except Exception as e:
            await ctx.send(f"❌ Ошибка снятия роли: {e}")

    # --- Команда для изменения ника самого пользователя (не бота) ---
    @bot.command(name="mynick", aliases=["сменить_мой_ник"])
    async def mynick_cmd(ctx, *, new_nick: str):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if len(new_nick) > 32:
            await ctx.send("❌ Никнейм не может быть длиннее 32 символов.")
            return
        if not ctx.author.guild_permissions.manage_nicknames and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на изменение никнейма.")
            return
        try:
            await ctx.author.edit(nick=new_nick)
            await ctx.send(f"✅ Ваш никнейм изменён на **{new_nick}**.")
        except discord.Forbidden:
            await ctx.send("❌ У бота нет прав на изменение вашего ника (проверьте, что бот имеет право управлять никнеймами).")
        except Exception as e:
            await ctx.send(f"❌ Ошибка смены ника: {e}")

    # --- Остальные команды (setoutput, purgewords, modlogs, massrole) ---
    @bot.command(name="setoutput", aliases=["канал_вывода", "вывод"])
    async def setoutput_cmd(ctx, channel: discord.TextChannel):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        if not ctx.author.guild_permissions.manage_guild and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на изменение настроек сервера.")
            return
        await bot.db.set_output_channel(str(ctx.guild.id), str(channel.id))
        await ctx.send(f"🎯 Канал вывода результатов для сервера настроен на: {channel.mention} (`{channel.id}`)")

    @bot.command(name="purgewords", aliases=["очистить_слово"])
    async def purgewords_cmd(ctx, word: str, limit: int = 15):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.author.guild_permissions.manage_messages and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на удаление сообщений.")
            return
        deleted = 0
        async for m in ctx.channel.history(limit=limit):
            if m.author.id == bot.user.id and word.lower() in m.content.lower():
                try:
                    await m.delete()
                    deleted += 1
                except Exception:
                    pass
        await ctx.send(f"🧹 Удалено `{deleted}` сообщений, содержащих слово «{word}».")

    @bot.command(name="modlogs", aliases=["лог_модерации"])
    async def modlogs_cmd(ctx):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.guild:
            await ctx.send("❌ Доступно только на сервере.")
            return
        logs = await bot.db.get_logs(limit=5)
        lines = ["🛡️ **Журнал событий модерации:**"]
        for l in logs:
            lines.append(f"• `[{l['timestamp'][:16]}]` [{l['level']}] {l['message']}")
        await ctx.send("\n".join(lines))

    @bot.command(name="massrole", aliases=["массовая_роль"])
    async def massrole_cmd(ctx, role: discord.Role):
        await bot.handle_slowmode(ctx.channel)
        if not ctx.author.guild_permissions.manage_roles and not ctx.author.guild_permissions.administrator:
            await ctx.send("❌ У вас нет прав на управление ролями.")
            return
        await ctx.send(f"⏳ Начинаю присвоение роли **{role.name}**...")
        count = 0
        for member in ctx.guild.members:
            if member != ctx.guild.me and not member.bot:
                try:
                    await member.add_roles(role)
                    count += 1
                    await asyncio.sleep(0.2)
                except:
                    pass
        await ctx.send(f"✅ Роль **{role.name}** выдана {count} участникам.")